import Layout from './DashboardLayout'

export default Layout
